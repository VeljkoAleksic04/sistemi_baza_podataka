namespace DigitalniRepozitorijum.Mapiranja;
using DigitalniRepozitorijum.Entiteti;
using FluentNHibernate.Mapping;

public class NizOcenaMap : ClassMap<NizOcena>
{
    public NizOcenaMap()
    {
        Id(x => x.Id, "Id_Ocene");
        
        Map(x => x.IdRundeRecenzije, "Id_Runde_Recenzije");
        Map(x => x.IdRecenzenta, "Id_recenzenta");
        Map(x => x.Kriterijum, "Kriterijum");
        Map(x => x.Ocena, "Ocena");
        
        // Samo mapa unazad ka VrsiRecenziju
        References(x => x.VrsiRecenziju)
            .Not.LazyLoad();

    }
}