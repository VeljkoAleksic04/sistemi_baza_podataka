namespace DigitalniRepozitorijum.Forme
{
    partial class NaucniRadoviForm
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            groupBox = new GroupBox();
            dataGridView = new DataGridView();
            colId = new DataGridViewTextBoxColumn();
            colNaslov = new DataGridViewTextBoxColumn();
            colDOI = new DataGridViewTextBoxColumn();
            colTipRada = new DataGridViewTextBoxColumn();
            colStranice = new DataGridViewTextBoxColumn();
            colIzvor = new DataGridViewTextBoxColumn();
            btnDodaj = new Button();
            btnIzmeni = new Button();
            btnObrisi = new Button();
            btnIzvor = new Button();
            richTextBox1 = new RichTextBox();
            groupBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView).BeginInit();
            SuspendLayout();
            // 
            // groupBox
            // 
            groupBox.Controls.Add(dataGridView);
            groupBox.Location = new Point(12, 12);
            groupBox.Name = "groupBox";
            groupBox.Size = new Size(690, 556);
            groupBox.TabIndex = 0;
            groupBox.TabStop = false;
            groupBox.Text = "Naučni radovi";
            // 
            // dataGridView
            // 
            dataGridView.AllowUserToAddRows = false;
            dataGridView.AllowUserToDeleteRows = false;
            dataGridView.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView.Columns.AddRange(new DataGridViewColumn[] { colId, colNaslov, colDOI, colTipRada, colStranice, colIzvor });
            dataGridView.Dock = DockStyle.Fill;
            dataGridView.Location = new Point(3, 19);
            dataGridView.MultiSelect = false;
            dataGridView.Name = "dataGridView";
            dataGridView.ReadOnly = true;
            dataGridView.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dataGridView.Size = new Size(684, 534);
            dataGridView.TabIndex = 0;
            dataGridView.CellContentClick += dataGridView_CellContentClick;
            // 
            // colId
            // 
            colId.DataPropertyName = "Id";
            colId.HeaderText = "Id";
            colId.Name = "colId";
            colId.ReadOnly = true;
            // 
            // colNaslov
            // 
            colNaslov.DataPropertyName = "Naslov";
            colNaslov.HeaderText = "Naslov";
            colNaslov.Name = "colNaslov";
            colNaslov.ReadOnly = true;
            // 
            // colDOI
            // 
            colDOI.DataPropertyName = "DOI";
            colDOI.HeaderText = "DOI";
            colDOI.Name = "colDOI";
            colDOI.ReadOnly = true;
            // 
            // colTipRada
            // 
            colTipRada.DataPropertyName = "TipRada";
            colTipRada.HeaderText = "TipRada";
            colTipRada.Name = "colTipRada";
            colTipRada.ReadOnly = true;
            // 
            // colStranice
            // 
            colStranice.DataPropertyName = "Stranice";
            colStranice.HeaderText = "Stranice";
            colStranice.Name = "colStranice";
            colStranice.ReadOnly = true;
            // 
            // colIzvor
            // 
            colIzvor.DataPropertyName = "Izvor";
            colIzvor.HeaderText = "Izvor";
            colIzvor.Name = "colIzvor";
            colIzvor.ReadOnly = true;
            // 
            // btnDodaj
            // 
            btnDodaj.Location = new Point(720, 12);
            btnDodaj.Name = "btnDodaj";
            btnDodaj.Size = new Size(240, 32);
            btnDodaj.TabIndex = 10;
            btnDodaj.Text = "Dodaj";
            btnDodaj.UseVisualStyleBackColor = true;
            btnDodaj.Click += btnDodaj_Click;
            // 
            // btnIzmeni
            // 
            btnIzmeni.Location = new Point(720, 50);
            btnIzmeni.Name = "btnIzmeni";
            btnIzmeni.Size = new Size(240, 32);
            btnIzmeni.TabIndex = 10;
            btnIzmeni.Text = "Izmeni";
            btnIzmeni.UseVisualStyleBackColor = true;
            btnIzmeni.Click += btnIzmeni_Click;
            // 
            // btnObrisi
            // 
            btnObrisi.Location = new Point(720, 88);
            btnObrisi.Name = "btnObrisi";
            btnObrisi.Size = new Size(240, 32);
            btnObrisi.TabIndex = 10;
            btnObrisi.Text = "Obrisi";
            btnObrisi.UseVisualStyleBackColor = true;
            btnObrisi.Click += btnObrisi_Click;
            // 
            // btnIzvor
            // 
            btnIzvor.Location = new Point(720, 140);
            btnIzvor.Name = "btnIzvor";
            btnIzvor.Size = new Size(240, 32);
            btnIzvor.TabIndex = 11;
            btnIzvor.Text = "Podaci o izvoru";
            btnIzvor.UseVisualStyleBackColor = true;
            btnIzvor.Click += btnIzvor_Click;
            // 
            // richTextBox1
            // 
            richTextBox1.Enabled = false;
            richTextBox1.Location = new Point(720, 190);
            richTextBox1.Name = "richTextBox1";
            richTextBox1.Size = new Size(240, 130);
            richTextBox1.TabIndex = 12;
            richTextBox1.Text = "";
            // 
            // NaucniRadoviForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(980, 580);
            Controls.Add(richTextBox1);
            Controls.Add(btnIzvor);
            Controls.Add(groupBox);
            Controls.Add(btnDodaj);
            Controls.Add(btnIzmeni);
            Controls.Add(btnObrisi);
            Name = "NaucniRadoviForm";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "NAUČNI RADOVI";
            Load += NaucniRadoviForm_Load;
            groupBox.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dataGridView).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox;
        private System.Windows.Forms.DataGridView dataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn colId;
        private System.Windows.Forms.DataGridViewTextBoxColumn colNaslov;
        private System.Windows.Forms.DataGridViewTextBoxColumn colDOI;
        private System.Windows.Forms.DataGridViewTextBoxColumn colTipRada;
        private System.Windows.Forms.DataGridViewTextBoxColumn colStranice;
        private System.Windows.Forms.DataGridViewTextBoxColumn colIzvor;
        private System.Windows.Forms.Button btnDodaj;
        private System.Windows.Forms.Button btnIzmeni;
        private System.Windows.Forms.Button btnObrisi;
        private Button btnIzvor;
        private RichTextBox richTextBox1;
    }
}
